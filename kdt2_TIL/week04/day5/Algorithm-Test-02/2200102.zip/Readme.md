# Test 02 Review

본 시험과 교육을 통해 파이썬 자료구조형 dictionary와 list, 
<br>그리고 그 method에 대해서 깊이 이해할 수 있게 되었습니다.
<br><br>이 기세로 프로젝트까지 진행해 한 사람 몫의 개발자가 될때까지
<br>쑥쑥 성장할 수 있으면 좋겠습니다! :fire: