from operator import attrgetter

from django.shortcuts import render, redirect
from .models import Post
from .forms import PostForm

# Create your views here.
def index(request):
    posts = Post.objects.all()
    context = {
        'posts': posts,
        'categories': [post[0] for post in Post.objects.distinct().values_list('category')],
    }
    return render(request, 'posts/index.html', context)


def detail(request, pk: int):
    post = Post.objects.filter(pk=pk)
    if not post:
        return redirect('posts:index')
    # if Post.objects.filter(pk=pk).exists():
    #     return redirect('posts:index')
    # post = Post.objects.filter(pk=pk)
    context = {
        'post': zip(
            ('제목', '내용', '카테고리', '작성일'), 
            attrgetter('title', 'content', 'category','created_at')(post[0])
        ),
        'pk': pk,
    }
    return render(request, 'posts/detail.html', context)


def create(request):
    if request.method == 'POST':
        form = PostForm(data=request.POST)
        if form.is_valid():
            post = form.save()
            return redirect('posts:detail', post.pk)
    else:
        form = PostForm()
    context = {
        'form': form,
    }
    return render(request, 'posts/create.html', context)


def delete(_, pk: int):
    Post.objects.get(pk=pk).delete()
    return redirect('posts:index')


def update(request, pk):
    post = Post.objects.get(pk=pk)
    if request.method == 'POST':
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            form.save()
            return redirect('posts:detail', pk)
    else:
        form = PostForm(instance=post)
        
    context = {
        'form': form,
        'pk': pk,
    }
    return render(request, 'posts/update.html', context)


def category(request, category_name):
    posts = Post.objects.filter(category=category_name)
    # print(Post.objects.only('category').distinct())
    # for i in Post.objects.only('category').distinct():
    #     print(i.category)
    context = {
        'posts': posts,
        'categories': [post[0] for post in Post.objects.distinct().values_list('category')],
    }
    return render(request, 'posts/index.html', context)