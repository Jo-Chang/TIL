from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class User(AbstractUser):
    birthday = models.DateField(null=True, blank=True)   # null과 빈 문자열 허용