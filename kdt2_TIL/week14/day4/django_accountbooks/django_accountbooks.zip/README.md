# 가계부 프로젝트
> 2023-03-31 금요일  
> 고봉진, 고영진, 김창조

---
# 참고자료
- [how to make a whole row in a table clickable](https://stackoverflow.com/questions/17147821/how-to-make-a-whole-row-in-a-table-clickable-as-a-link)